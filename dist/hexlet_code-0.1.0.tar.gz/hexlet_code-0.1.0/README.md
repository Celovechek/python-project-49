### Hexlet tests and linter status:
[![Actions Status](https://github.com/Celovechek/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Celovechek/python-project-49/actions)

### CodeClimate Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/88ce675dc28e290e0fce/maintainability)](https://codeclimate.com/github/Celovechek/python-project-49/maintainability)
