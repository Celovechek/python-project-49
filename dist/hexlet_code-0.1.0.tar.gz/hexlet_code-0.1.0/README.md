### Hexlet tests and linter status:
[![Actions Status](https://github.com/Celovechek/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Celovechek/python-project-49/actions)

### CodeClimate Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/88ce675dc28e290e0fce/maintainability)](https://codeclimate.com/github/Celovechek/python-project-49/maintainability)

### Asciinema (installation + brain-even game)
[![asciicast](https://asciinema.org/a/2RnJzck1na3CdnME65l9zUG0V.svg)](https://asciinema.org/a/2RnJzck1na3CdnME65l9zUG0V)

### Asciinema (brain-calc game)
[![asciicast](https://asciinema.org/a/S44WzflWVI9qatIuG0v4ll7xV.svg)](https://asciinema.org/a/S44WzflWVI9qatIuG0v4ll7xV)

### Asciinema (brain-gcd game)
[![asciicast](https://asciinema.org/a/2GPSCKwtgWfeUvb5q1TMcihgS.svg)](https://asciinema.org/a/2GPSCKwtgWfeUvb5q1TMcihgS)

### Asciinema (brain-progression game)
[![asciicast](https://asciinema.org/a/5UDeFPVdLLbF3pD2qOrlR1g9I.svg)](https://asciinema.org/a/5UDeFPVdLLbF3pD2qOrlR1g9I)

### Asciinema (brain-prime game)
[![asciicast](https://asciinema.org/a/8CBBlEONqmpVmMJk7qNbsZGGh.svg)](https://asciinema.org/a/8CBBlEONqmpVmMJk7qNbsZGGh)
